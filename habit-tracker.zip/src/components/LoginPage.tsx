import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Mail, Sparkles, AlertCircle, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface LoginPageProps {
  onLogin: (profile: UserProfile) => void;
  initialEmail?: string;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin, initialEmail = 'aditya.123.22.111@gmail.com' }) => {
  const [email, setEmail] = useState(initialEmail);
  const [name, setName] = useState('Aditya');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setError('Please enter your Google Email / Gmail address.');
      return;
    }
    if (!email.includes('@') || !email.endsWith('.com')) {
      setError('Please enter a valid Gmail or Google Workspace email address.');
      return;
    }
    if (!name.trim()) {
      setError('Please enter your name.');
      return;
    }

    setError(null);
    setIsSubmitting(true);

    // Simulate authentic Google Identity services connection
    setTimeout(() => {
      setIsSubmitting(false);
      onLogin({
        email: email.trim().toLowerCase(),
        name: name.trim(),
        avatarUrl: `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(email.trim())}`,
      });
    }, 1200);
  };

  const handleQuickLogin = (quickEmail: string, quickName: string) => {
    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      onLogin({
        email: quickEmail,
        name: quickName,
        avatarUrl: `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(quickEmail)}`,
      });
    }, 800);
  };

  return (
    <div className="min-h-screen bg-[#f5f5f0] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 font-serif">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="w-16 h-16 bg-white rounded-full shadow-sm border border-[#e6e6db] flex items-center justify-center text-[#5A5A40] mb-2 italic text-2xl font-bold"
          >
            H
          </motion.div>
        </div>
        <h2 className="mt-4 text-center text-3xl font-bold tracking-tight text-[#4a4a35] font-serif">
          Habit tracker
        </h2>
        <p className="mt-2 text-center text-sm text-[#8a8a70] font-sans italic max-w">
          Enter your Google account details to sync your routines and achievements.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1, duration: 0.4 }}
          className="bg-white py-8 px-4 shadow-sm rounded-[24px] border border-[#e6e6db] sm:px-10"
        >
          {error && (
            <div className="mb-4 bg-rose-50 border border-rose-100 text-rose-700 p-3 rounded-xl flex items-start gap-2 text-sm font-sans">
              <AlertCircle size={18} className="shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form className="space-y-6 font-sans" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-[#4a4a35]">
                Full Name
              </label>
              <div className="mt-1">
                <input
                  id="name"
                  name="name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your Name"
                  className="appearance-none block w-full px-4 py-3 border border-[#e6e6db] rounded-xl shadow-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#5A5A40] focus:border-[#5A5A40] text-[#33332d] bg-[#f5f5f0]/30 transition"
                />
              </div>
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-[#4a4a35]">
                Google Email / Gmail
              </label>
              <div className="mt-1 relative rounded-md shadow-xs">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Mail size={18} />
                </div>
                <input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@gmail.com"
                  className="appearance-none block w-full pl-10 pr-4 py-3 border border-[#e6e6db] rounded-xl shadow-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#5A5A40] focus:border-[#5A5A40] text-[#33332d] bg-[#f5f5f0]/30 transition"
                />
              </div>
            </div>

            <div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-full shadow-xs text-sm font-semibold text-white bg-[#D4A373] hover:bg-[#c69363] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#5A5A40] transition disabled:opacity-50 cursor-pointer"
              >
                {isSubmitting ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Signing in...</span>
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2 w-full">
                    <span>Continue with Gmail</span>
                    <ArrowRight size={16} />
                  </div>
                )}
              </button>
            </div>
          </form>

          <div className="mt-6 font-sans">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-[#e6e6db]" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-3 text-[#8a8a70] font-medium">Or Quick Sign-In</span>
              </div>
            </div>

            <div className="mt-4 space-y-2">
              <button
                onClick={() => handleQuickLogin(initialEmail, 'Aditya')}
                disabled={isSubmitting}
                className="w-full flex items-center justify-between px-4 py-3 border border-[#e6e6db] rounded-xl text-sm font-medium text-slate-700 bg-[#f5f5f0]/50 hover:bg-[#f5f5f0] transition active:scale-98 cursor-pointer"
              >
                <div className="flex items-center gap-2 truncate">
                  <div className="w-6 h-6 rounded-full bg-[#5A5A40] text-white font-bold flex items-center justify-center text-xs">
                    A
                  </div>
                  <div className="text-left truncate">
                    <p className="font-semibold text-[#33332d] text-xs leading-none">Aditya (User Profile)</p>
                    <p className="text-[10px] text-[#8a8a70] truncate mt-0.5">{initialEmail}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-[#5A5A40] font-semibold">
                  <span>Sign In</span>
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
              </button>

              <button
                onClick={() => handleQuickLogin('demo.tracker@gmail.com', 'Demo User')}
                disabled={isSubmitting}
                className="w-full flex items-center justify-between px-4 py-3 border border-[#e6e6db] rounded-xl text-sm font-medium text-slate-700 bg-[#f5f5f0]/50 hover:bg-[#f5f5f0] transition active:scale-98 cursor-pointer"
              >
                <div className="flex items-center gap-2 truncate">
                  <div className="w-6 h-6 rounded-full bg-[#D4A373] text-white font-bold flex items-center justify-center text-xs">
                    D
                  </div>
                  <div className="text-left truncate">
                    <p className="font-semibold text-[#33332d] text-xs leading-none">Demo Account</p>
                    <p className="text-[10px] text-[#8a8a70] truncate mt-0.5">demo.tracker@gmail.com</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-[#D4A373] font-semibold">
                  <span>Sign In</span>
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
              </button>
            </div>
          </div>
        </motion.div>

        <p className="mt-6 text-center text-xs text-[#8a8a70] font-sans italic">
          By signing in, your data is saved securely in your local sandbox storage.
        </p>
      </div>
    </div>
  );
};
