import React from 'react';
import { Habit, Area } from '../types';
import { IconRenderer } from './IconRenderer';
import { Edit2 } from 'lucide-react';

interface HabitCardProps {
  habit: Habit;
  area?: Area;
  onEdit: (habit: Habit) => void;
}

export const HabitCard: React.FC<HabitCardProps> = ({ habit, area, onEdit }) => {
  return (
    <div className="group bg-white p-5 rounded-[24px] border border-[#e6e6db] shadow-xs hover:shadow-sm hover:border-[#5A5A40]/40 transition duration-250 relative flex items-center gap-4">
      {/* Icon Area */}
      <div className="w-14 h-14 bg-[#f5f5f0] border border-[#e6e6db] rounded-[16px] flex items-center justify-center text-[#5A5A40] shrink-0">
        <IconRenderer name={habit.icon} size={22} />
      </div>

      {/* Details Area */}
      <div className="flex-1 min-w-0 font-serif">
        <div className="flex items-center justify-between gap-1">
          <h4 className="font-bold text-[#33332d] text-base tracking-tight truncate group-hover:text-[#5A5A40] transition">
            {habit.name}
          </h4>
          
          <button
            onClick={() => onEdit(habit)}
            className="opacity-0 group-hover:opacity-100 p-1 text-[#8a8a70] hover:text-[#33332d] rounded-lg hover:bg-[#f5f5f0] transition shrink-0"
            title="Edit this habit"
          >
            <Edit2 size={13} />
          </button>
        </div>

        {/* 2x2 Aligned Specs Grid - mimicking the exact image style */}
        <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 mt-2 text-[11px] font-sans font-medium text-[#8a8a70] leading-relaxed">
          <div className="truncate">
            <span className="text-[#a1a18c]">Category:</span> <span className="text-[#33332d] font-bold">{area?.name || 'General'}</span>
          </div>
          <div className="text-right truncate font-bold text-[#5A5A40]">
            {habit.difficulty}
          </div>
          <div className="truncate col-span-2">
            <span className="text-[#a1a18c]">Duration:</span> <span className="text-[#33332d] font-bold">{habit.time}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
