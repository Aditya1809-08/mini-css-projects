import React, { useState } from 'react';
import { Area, Habit, RoutineItem, Difficulty } from '../types';
import { X, Plus, Trash2, Edit2, Check, Sparkles } from 'lucide-react';
import { IconRenderer, SELECTABLE_ICONS } from './IconRenderer';

interface EditModalProps {
  isOpen: boolean;
  onClose: () => void;
  areas: Area[];
  habits: Habit[];
  routines: RoutineItem[];
  onSaveAreas: (areas: Area[]) => void;
  onSaveHabits: (habits: Habit[]) => void;
  onSaveRoutines: (routines: RoutineItem[]) => void;
  initialTab?: 'habits' | 'areas' | 'routines';
}

export const EditModal: React.FC<EditModalProps> = ({
  isOpen,
  onClose,
  areas,
  habits,
  routines,
  onSaveAreas,
  onSaveHabits,
  onSaveRoutines,
  initialTab = 'habits',
}) => {
  const [activeTab, setActiveTab] = useState<'habits' | 'areas' | 'routines'>(initialTab);

  // Form states for Habit
  const [editingHabitId, setEditingHabitId] = useState<string | null>(null);
  const [habitName, setHabitName] = useState('');
  const [habitAreaId, setHabitAreaId] = useState('');
  const [habitDifficulty, setHabitDifficulty] = useState<Difficulty>('Medium');
  const [habitTime, setHabitTime] = useState('30 min');
  const [habitIcon, setHabitIcon] = useState('Activity');

  // Form states for Area
  const [editingAreaId, setEditingAreaId] = useState<string | null>(null);
  const [areaName, setAreaName] = useState('');
  const [areaIcon, setAreaIcon] = useState('User');
  const [areaColor, setAreaColor] = useState('bg-slate-50 text-slate-600 border-slate-100');

  // Form states for Routine Item
  const [editingRoutineId, setEditingRoutineId] = useState<string | null>(null);
  const [routineHabitId, setRoutineHabitId] = useState('');
  const [routineTime, setRoutineTime] = useState('15 min');
  const [routinePeriod, setRoutinePeriod] = useState<'Morning' | 'Evening'>('Morning');

  const COLOR_OPTIONS = [
    { class: 'bg-[#5A5A40]/10 text-[#5A5A40] border-[#cbd5c1]', name: 'Sage Green' },
    { class: 'bg-[#D4A373]/10 text-[#D4A373] border-[#e6c29d]', name: 'Terracotta' },
    { class: 'bg-[#a9bca1]/10 text-[#4c5c45] border-[#a9bca1]/40', name: 'Olive Green' },
    { class: 'bg-[#eedbb2]/10 text-[#7a5c1a] border-[#eedbb2]/40', name: 'Sand Warmth' },
    { class: 'bg-[#e2c1c0]/10 text-[#7c4847] border-[#e2c1c0]/40', name: 'Clay Red' },
    { class: 'bg-[#d8d3c5]/10 text-[#545148] border-[#d8d3c5]/40', name: 'Pebble Gray' },
    { class: 'bg-[#c1d1db]/10 text-[#3a5260] border-[#c1d1db]/40', name: 'Mineral Blue' },
    { class: 'bg-[#ebdcd0]/10 text-[#7a593e] border-[#ebdcd0]/40', name: 'Warm Almond' },
  ];

  if (!isOpen) return null;

  // --- HABITS ACTIONS ---
  const handleEditHabit = (habit: Habit) => {
    setEditingHabitId(habit.id);
    setHabitName(habit.name);
    setHabitAreaId(habit.areaId);
    setHabitDifficulty(habit.difficulty);
    setHabitTime(habit.time);
    setHabitIcon(habit.icon);
  };

  const handleCreateHabit = () => {
    setEditingHabitId('new');
    setHabitName('');
    setHabitAreaId(areas[0]?.id || '');
    setHabitDifficulty('Medium');
    setHabitTime('20 min');
    setHabitIcon('Activity');
  };

  const handleSaveHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!habitName.trim() || !habitAreaId) return;

    if (editingHabitId === 'new') {
      const newHabit: Habit = {
        id: `habit-${Date.now()}`,
        name: habitName.trim(),
        areaId: habitAreaId,
        difficulty: habitDifficulty,
        time: habitTime,
        icon: habitIcon,
      };
      onSaveHabits([...habits, newHabit]);
    } else if (editingHabitId) {
      const updated = habits.map((h) =>
        h.id === editingHabitId
          ? { ...h, name: habitName.trim(), areaId: habitAreaId, difficulty: habitDifficulty, time: habitTime, icon: habitIcon }
          : h
      );
      onSaveHabits(updated);
    }
    setEditingHabitId(null);
  };

  const handleDeleteHabit = (id: string) => {
    if (confirm('Are you sure you want to delete this habit? It will be removed from routines as well.')) {
      onSaveHabits(habits.filter((h) => h.id !== id));
      onSaveRoutines(routines.filter((r) => r.habitId !== id));
    }
  };

  // --- AREAS ACTIONS ---
  const handleEditArea = (area: Area) => {
    setEditingAreaId(area.id);
    setAreaName(area.name);
    setAreaIcon(area.icon);
    setAreaColor(area.color);
  };

  const handleCreateArea = () => {
    setEditingAreaId('new');
    setAreaName('');
    setAreaIcon('Target');
    setAreaColor(COLOR_OPTIONS[0].class);
  };

  const handleSaveArea = (e: React.FormEvent) => {
    e.preventDefault();
    if (!areaName.trim()) return;

    if (editingAreaId === 'new') {
      const newArea: Area = {
        id: `area-${Date.now()}`,
        name: areaName.trim(),
        icon: areaIcon,
        color: areaColor,
      };
      onSaveAreas([...areas, newArea]);
    } else if (editingAreaId) {
      const updated = areas.map((a) =>
        a.id === editingAreaId ? { ...a, name: areaName.trim(), icon: areaIcon, color: areaColor } : a
      );
      onSaveAreas(updated);
    }
    setEditingAreaId(null);
  };

  const handleDeleteArea = (id: string) => {
    if (areas.length <= 1) {
      alert('You must keep at least one Area category.');
      return;
    }
    if (confirm('Deleting this Area will also delete or un-categorize all associated habits. Proceed?')) {
      onSaveAreas(areas.filter((a) => a.id !== id));
      // Re-map or delete habits in this area
      const habitsToDelete = habits.filter((h) => h.areaId === id).map((h) => h.id);
      onSaveHabits(habits.filter((h) => h.areaId !== id));
      onSaveRoutines(routines.filter((r) => !habitsToDelete.includes(r.habitId)));
    }
  };

  // --- ROUTINES ACTIONS ---
  const handleEditRoutine = (item: RoutineItem) => {
    setEditingRoutineId(item.id);
    setRoutineHabitId(item.habitId);
    setRoutineTime(item.time);
    setRoutinePeriod(item.period);
  };

  const handleCreateRoutine = () => {
    setEditingRoutineId('new');
    setRoutineHabitId(habits[0]?.id || '');
    setRoutineTime('10 min');
    setRoutinePeriod('Morning');
  };

  const handleSaveRoutine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!routineHabitId) return;

    if (editingRoutineId === 'new') {
      const newItem: RoutineItem = {
        id: `routine-${Date.now()}`,
        habitId: routineHabitId,
        time: routineTime,
        period: routinePeriod,
      };
      onSaveRoutines([...routines, newItem]);
    } else if (editingRoutineId) {
      const updated = routines.map((r) =>
        r.id === editingRoutineId
          ? { ...r, habitId: routineHabitId, time: routineTime, period: routinePeriod }
          : r
      );
      onSaveRoutines(updated);
    }
    setEditingRoutineId(null);
  };

  const handleDeleteRoutine = (id: string) => {
    if (confirm('Are you sure you want to remove this habit from the routine list?')) {
      onSaveRoutines(routines.filter((r) => r.id !== id));
    }
  };

  return (
    <div className="fixed inset-0 bg-[#33332d]/40 backdrop-blur-xs z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-[32px] w-full max-w-2xl shadow-xl border border-[#e6e6db] flex flex-col max-h-[90vh] font-serif">
        
        {/* Header */}
        <div className="p-6 border-b border-[#e6e6db] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-[#5A5A40]/10 text-[#5A5A40] rounded-xl">
              <Edit2 size={20} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-[#33332d]">Customizer & Editor</h3>
              <p className="text-xs text-[#8a8a70] font-sans italic">Edit, add, or remove habits, categories, and routines</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[#f5f5f0] text-[#8a8a70] hover:text-[#33332d] rounded-full transition cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex bg-[#f5f5f0]/80 p-1.5 mx-6 mt-4 rounded-2xl border border-[#e6e6db] font-sans">
          <button
            onClick={() => { setActiveTab('habits'); setEditingHabitId(null); }}
            className={`flex-1 py-2 px-3 rounded-xl text-sm font-bold transition cursor-pointer ${
              activeTab === 'habits' ? 'bg-white text-[#33332d] shadow-xs' : 'text-[#8a8a70] hover:text-[#33332d]'
            }`}
          >
            Habits ({habits.length})
          </button>
          <button
            onClick={() => { setActiveTab('areas'); setEditingAreaId(null); }}
            className={`flex-1 py-2 px-3 rounded-xl text-sm font-bold transition cursor-pointer ${
              activeTab === 'areas' ? 'bg-white text-[#33332d] shadow-xs' : 'text-[#8a8a70] hover:text-[#33332d]'
            }`}
          >
            Areas ({areas.length})
          </button>
          <button
            onClick={() => { setActiveTab('routines'); setEditingRoutineId(null); }}
            className={`flex-1 py-2 px-3 rounded-xl text-sm font-bold transition cursor-pointer ${
              activeTab === 'routines' ? 'bg-white text-[#33332d] shadow-xs' : 'text-[#8a8a70] hover:text-[#33332d]'
            }`}
          >
            Routines ({routines.length})
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 font-sans">
          
          {/* ===================== HABITS TAB ===================== */}
          {activeTab === 'habits' && (
            <div className="space-y-4">
              {editingHabitId ? (
                <form onSubmit={handleSaveHabit} className="bg-[#f5f5f0]/30 p-5 rounded-2xl border border-[#e6e6db] space-y-4">
                  <div className="flex items-center justify-between border-b border-[#e6e6db] pb-3 mb-2 font-serif">
                    <h4 className="font-bold text-[#33332d]">
                      {editingHabitId === 'new' ? '✨ Add New Habit' : '📝 Edit Habit'}
                    </h4>
                    <button
                      type="button"
                      onClick={() => setEditingHabitId(null)}
                      className="text-xs text-[#8a8a70] hover:text-[#33332d] font-bold"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#8a8a70] uppercase mb-1">Habit Name</label>
                      <input
                        type="text"
                        required
                        value={habitName}
                        onChange={(e) => setHabitName(e.target.value)}
                        placeholder="e.g., Reading, Workout..."
                        className="w-full px-3 py-2 border border-[#e6e6db] rounded-xl text-sm text-[#33332d] focus:outline-none focus:ring-2 focus:ring-[#5A5A40] bg-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#8a8a70] uppercase mb-1">Category / Area</label>
                      <select
                        value={habitAreaId}
                        onChange={(e) => setHabitAreaId(e.target.value)}
                        className="w-full px-3 py-2 border border-[#e6e6db] rounded-xl text-sm text-[#33332d] focus:outline-none focus:ring-2 focus:ring-[#5A5A40] bg-white"
                      >
                        {areas.map((a) => (
                           <option key={a.id} value={a.id}>{a.name}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#8a8a70] uppercase mb-1">Difficulty</label>
                      <div className="flex gap-2">
                        {(['Easy', 'Medium', 'Hard'] as Difficulty[]).map((d) => (
                          <button
                            key={d}
                            type="button"
                            onClick={() => setHabitDifficulty(d)}
                            className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition cursor-pointer ${
                              habitDifficulty === d
                                ? 'bg-[#5A5A40] border-[#5A5A40] text-white'
                                : 'bg-white border-[#e6e6db] text-[#8a8a70] hover:bg-[#f5f5f0]'
                            }`}
                          >
                            {d}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#8a8a70] uppercase mb-1">Timing / Duration</label>
                      <input
                        type="text"
                        required
                        value={habitTime}
                        onChange={(e) => setHabitTime(e.target.value)}
                        placeholder="e.g., 30 min, 1 hour..."
                        className="w-full px-3 py-2 border border-[#e6e6db] rounded-xl text-sm text-[#33332d] focus:outline-none focus:ring-2 focus:ring-[#5A5A40] bg-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#8a8a70] uppercase mb-2">Select Icon</label>
                    <div className="grid grid-cols-5 gap-2 max-h-28 overflow-y-auto p-1.5 bg-white border border-[#e6e6db] rounded-xl">
                      {SELECTABLE_ICONS.map((ico) => (
                        <button
                          key={ico.name}
                          type="button"
                          onClick={() => setHabitIcon(ico.name)}
                          title={ico.label}
                          className={`p-2 flex flex-col items-center justify-center rounded-lg border transition cursor-pointer ${
                            habitIcon === ico.name
                              ? 'bg-[#5A5A40]/10 border-[#5A5A40] text-[#5A5A40] scale-105'
                              : 'border-transparent text-[#8a8a70] hover:bg-[#f5f5f0]/50'
                          }`}
                        >
                          <IconRenderer name={ico.name} size={18} />
                          <span className="text-[9px] mt-1 text-[#8a8a70] truncate w-full text-center">{ico.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#D4A373] hover:bg-[#c69363] text-white py-2.5 rounded-full font-bold text-sm transition shadow-xs cursor-pointer"
                  >
                    Save Habit Details
                  </button>
                </form>
              ) : (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <h4 className="text-sm font-bold text-[#8a8a70]">All Registered Habits</h4>
                    <button
                      onClick={handleCreateHabit}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-[#5A5A40]/10 text-[#5A5A40] rounded-xl text-xs font-bold hover:bg-[#5A5A40]/20 transition cursor-pointer"
                    >
                      <Plus size={14} />
                      <span>Add Habit</span>
                    </button>
                  </div>

                  {habits.length === 0 ? (
                    <div className="text-center py-10 bg-[#f5f5f0]/30 rounded-2xl border border-dashed border-[#e6e6db]">
                      <p className="text-sm text-[#8a8a70] italic">No habits added yet. Create one above!</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {habits.map((h) => {
                        const area = areas.find((a) => a.id === h.areaId);
                        return (
                          <div key={h.id} className="bg-white p-4 rounded-2xl border border-[#e6e6db] shadow-xs hover:border-[#5A5A40]/30 transition flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <div className="p-2.5 bg-[#f5f5f0] text-[#5A5A40] rounded-xl border border-[#e6e6db]">
                                <IconRenderer name={h.icon} size={18} />
                              </div>
                              <div>
                                <p className="font-bold text-[#33332d] text-sm">{h.name}</p>
                                <div className="flex items-center gap-2 mt-0.5">
                                  <span className="text-[10px] bg-[#f5f5f0] text-[#5A5A40] px-1.5 py-0.5 rounded font-bold">
                                    {area?.name || 'Uncategorized'}
                                  </span>
                                  <span className="text-[10px] text-[#8a8a70] font-bold">
                                    {h.time} • {h.difficulty}
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="flex gap-1.5">
                              <button
                                onClick={() => handleEditHabit(h)}
                                className="p-1.5 hover:bg-[#f5f5f0] text-[#8a8a70] hover:text-[#33332d] rounded-lg transition cursor-pointer"
                                title="Edit"
                              >
                                <Edit2 size={14} />
                              </button>
                              <button
                                onClick={() => handleDeleteHabit(h.id)}
                                className="p-1.5 hover:bg-rose-50 text-rose-400 hover:text-rose-600 rounded-lg transition cursor-pointer"
                                title="Delete"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* ===================== AREAS TAB ===================== */}
          {activeTab === 'areas' && (
            <div className="space-y-4">
              {editingAreaId ? (
                <form onSubmit={handleSaveArea} className="bg-[#f5f5f0]/30 p-5 rounded-2xl border border-[#e6e6db] space-y-4">
                  <div className="flex items-center justify-between border-b border-[#e6e6db] pb-3 mb-2 font-serif">
                    <h4 className="font-bold text-[#33332d]">
                      {editingAreaId === 'new' ? '✨ Create New Area' : '📝 Edit Area'}
                    </h4>
                    <button
                      type="button"
                      onClick={() => setEditingAreaId(null)}
                      className="text-xs text-[#8a8a70] hover:text-[#33332d] font-bold"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#8a8a70] uppercase mb-1">Area Name</label>
                      <input
                        type="text"
                        required
                        value={areaName}
                        onChange={(e) => setAreaName(e.target.value)}
                        placeholder="e.g., Work, Sports, Arts..."
                        className="w-full px-3 py-2 border border-[#e6e6db] rounded-xl text-sm text-[#33332d] focus:outline-none focus:ring-2 focus:ring-[#5A5A40] bg-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#8a8a70] uppercase mb-1">Color Palette</label>
                      <div className="grid grid-cols-4 gap-2">
                        {COLOR_OPTIONS.map((c) => (
                          <button
                            key={c.name}
                            type="button"
                            onClick={() => setAreaColor(c.class)}
                            title={c.name}
                            className={`h-8 rounded-lg border flex items-center justify-center transition text-xs font-bold cursor-pointer ${c.class} ${
                              areaColor === c.class ? 'ring-2 ring-[#5A5A40] scale-102 border-[#5A5A40]' : 'border-transparent'
                            }`}
                          >
                            {areaColor === c.class && <Check size={12} />}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#8a8a70] uppercase mb-2">Select Icon</label>
                    <div className="grid grid-cols-5 gap-2 max-h-28 overflow-y-auto p-1.5 bg-white border border-[#e6e6db] rounded-xl">
                      {SELECTABLE_ICONS.map((ico) => (
                        <button
                          key={ico.name}
                          type="button"
                          onClick={() => setAreaIcon(ico.name)}
                          className={`p-2 flex flex-col items-center justify-center rounded-lg border transition cursor-pointer ${
                            areaIcon === ico.name
                              ? 'bg-[#5A5A40]/10 border-[#5A5A40] text-[#5A5A40]'
                              : 'border-transparent text-[#8a8a70] hover:bg-[#f5f5f0]/50'
                          }`}
                        >
                          <IconRenderer name={ico.name} size={18} />
                          <span className="text-[9px] mt-1 text-[#8a8a70] truncate w-full text-center">{ico.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#D4A373] hover:bg-[#c69363] text-white py-2.5 rounded-full font-bold text-sm transition shadow-xs cursor-pointer"
                  >
                    Save Area Details
                  </button>
                </form>
              ) : (
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <h4 className="text-sm font-bold text-[#8a8a70]">Habit Areas / Categories</h4>
                    <button
                      onClick={handleCreateArea}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-[#5A5A40]/10 text-[#5A5A40] rounded-xl text-xs font-bold hover:bg-[#5A5A40]/20 transition cursor-pointer"
                    >
                      <Plus size={14} />
                      <span>Add Area</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {areas.map((a) => {
                      const habitCount = habits.filter((h) => h.areaId === a.id).length;
                      return (
                        <div key={a.id} className="bg-white p-4 rounded-2xl border border-[#e6e6db] shadow-xs flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className={`p-2.5 rounded-xl border ${a.color}`}>
                              <IconRenderer name={a.icon} size={18} />
                            </div>
                            <div>
                              <p className="font-bold text-[#33332d] text-sm">{a.name}</p>
                              <p className="text-[11px] text-[#8a8a70] font-bold">
                                {habitCount} associated {habitCount === 1 ? 'habit' : 'habits'}
                              </p>
                            </div>
                          </div>

                          <div className="flex gap-1.5">
                            <button
                              onClick={() => handleEditArea(a)}
                              className="p-1.5 hover:bg-[#f5f5f0] text-[#8a8a70] hover:text-[#33332d] rounded-lg transition cursor-pointer"
                              title="Edit"
                            >
                              <Edit2 size={14} />
                            </button>
                            <button
                              onClick={() => handleDeleteArea(a.id)}
                              className="p-1.5 hover:bg-rose-50 text-rose-400 hover:text-rose-600 rounded-lg transition cursor-pointer"
                              title="Delete"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ===================== ROUTINES TAB ===================== */}
          {activeTab === 'routines' && (
            <div className="space-y-4">
              {editingRoutineId ? (
                <form onSubmit={handleSaveRoutine} className="bg-[#f5f5f0]/30 p-5 rounded-2xl border border-[#e6e6db] space-y-4">
                  <div className="flex items-center justify-between border-b border-[#e6e6db] pb-3 mb-2 font-serif">
                    <h4 className="font-bold text-[#33332d]">
                      {editingRoutineId === 'new' ? '✨ Add Routine Item' : '📝 Edit Routine Item'}
                    </h4>
                    <button
                      type="button"
                      onClick={() => setEditingRoutineId(null)}
                      className="text-xs text-[#8a8a70] hover:text-[#33332d] font-bold"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-[#8a8a70] uppercase mb-1">Link to Habit</label>
                      <select
                        value={routineHabitId}
                        onChange={(e) => setRoutineHabitId(e.target.value)}
                        className="w-full px-3 py-2 border border-[#e6e6db] rounded-xl text-sm text-[#33332d] focus:outline-none focus:ring-2 focus:ring-[#5A5A40] bg-white"
                      >
                        {habits.map((h) => (
                          <option key={h.id} value={h.id}>{h.name}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#8a8a70] uppercase mb-1">Time Assigned</label>
                      <input
                        type="text"
                        required
                        value={routineTime}
                        onChange={(e) => setRoutineTime(e.target.value)}
                        placeholder="e.g., 5 min, 45 min..."
                        className="w-full px-3 py-2 border border-[#e6e6db] rounded-xl text-sm text-[#33332d] focus:outline-none focus:ring-2 focus:ring-[#5A5A40] bg-white"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-[#8a8a70] uppercase mb-1">Day Period</label>
                      <div className="flex gap-2">
                        {['Morning', 'Evening'].map((p) => (
                          <button
                            key={p}
                            type="button"
                            onClick={() => setRoutinePeriod(p as any)}
                            className={`flex-1 py-1.5 rounded-lg text-xs font-bold border transition cursor-pointer ${
                              routinePeriod === p
                                ? 'bg-[#5A5A40] border-[#5A5A40] text-white'
                                : 'bg-white border-[#e6e6db] text-[#8a8a70] hover:bg-[#f5f5f0]'
                            }`}
                          >
                            {p}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#D4A373] hover:bg-[#c69363] text-white py-2.5 rounded-full font-bold text-sm transition shadow-xs cursor-pointer"
                  >
                    Save Routine Link
                  </button>
                </form>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="text-sm font-bold text-[#8a8a70]">Allocated Day Routines</h4>
                    <button
                      disabled={habits.length === 0}
                      onClick={handleCreateRoutine}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-[#5A5A40]/10 text-[#5A5A40] rounded-xl text-xs font-bold hover:bg-[#5A5A40]/20 transition disabled:opacity-50 cursor-pointer"
                    >
                      <Plus size={14} />
                      <span>Add Routine Item</span>
                    </button>
                  </div>

                  {habits.length === 0 && (
                    <p className="text-xs text-rose-500 font-bold">Please create at least one Habit first before building routine logs.</p>
                  )}

                  {['Morning', 'Evening'].map((period) => {
                    const items = routines.filter((r) => r.period === period);
                    return (
                      <div key={period} className="space-y-2">
                        <h5 className="text-xs font-bold text-[#8a8a70] uppercase tracking-wider font-sans">{period} block</h5>
                        {items.length === 0 ? (
                          <div className="py-4 px-4 border border-dashed border-[#e6e6db] rounded-2xl text-center text-xs text-[#8a8a70] bg-[#f5f5f0]/30 italic">
                            No {period.toLowerCase()} routine items yet.
                          </div>
                        ) : (
                          <div className="space-y-1.5">
                            {items.map((item) => {
                              const habit = habits.find((h) => h.id === item.habitId);
                              return (
                                <div key={item.id} className="bg-white px-4 py-2.5 rounded-xl border border-[#e6e6db] flex items-center justify-between text-xs">
                                  <div className="flex items-center gap-2">
                                    <span className="p-1.5 bg-[#f5f5f0] text-[#5A5A40] rounded-lg">
                                      <IconRenderer name={habit?.icon || 'Check'} size={14} />
                                    </span>
                                    <div>
                                      <p className="font-bold text-[#33332d]">{habit?.name || 'Deleted Habit'}</p>
                                      <p className="text-[10px] text-[#8a8a70] font-bold mt-0.5">Assigned Duration: {item.time}</p>
                                    </div>
                                  </div>

                                  <div className="flex gap-1 font-sans">
                                    <button
                                      onClick={() => handleEditRoutine(item)}
                                      className="p-1 hover:bg-[#f5f5f0] text-[#8a8a70] hover:text-[#33332d] rounded cursor-pointer"
                                      title="Edit"
                                    >
                                      <Edit2 size={12} />
                                    </button>
                                    <button
                                      onClick={() => handleDeleteRoutine(item.id)}
                                      className="p-1 hover:bg-rose-50 text-rose-400 hover:text-rose-600 rounded cursor-pointer"
                                      title="Delete"
                                    >
                                      <Trash2 size={12} />
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer info */}
        <div className="p-4 border-t border-[#e6e6db] bg-[#f5f5f0]/80 rounded-b-[32px] text-center text-[11px] text-[#8a8a70] flex items-center justify-center gap-1.5">
          <Sparkles size={12} className="text-[#D4A373]" />
          <span>All custom edits are stored locally and will adapt your stats automatically!</span>
        </div>

      </div>
    </div>
  );
};
