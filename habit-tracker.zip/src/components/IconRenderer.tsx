import React from 'react';
import * as LucideIcons from 'lucide-react';

interface IconRendererProps {
  name: string;
  className?: string;
  size?: number;
}

export const IconRenderer: React.FC<IconRendererProps> = ({
  name,
  className = '',
  size = 20,
}) => {
  // Resolve icon component dynamically from lucide-react exports
  const IconComponent = (LucideIcons as any)[name];

  if (!IconComponent) {
    // Return a safe generic fallback (e.g., Circle) if the requested icon isn't found
    const Fallback = LucideIcons.Circle;
    return <Fallback className={className} size={size} />;
  }

  return <IconComponent className={className} size={size} />;
};

// A list of popular, nice-looking icons that users can select when creating/editing areas or habits
export const SELECTABLE_ICONS = [
  { name: 'User', label: 'Personal / Avatar' },
  { name: 'Dumbbell', label: 'Fitness / Gym' },
  { name: 'BookOpen', label: 'Learning / Reading' },
  { name: 'DollarSign', label: 'Finance / Wealth' },
  { name: 'HeartPulse', label: 'Health / Heartbeat' },
  { name: 'Sprout', label: 'Sprout / Growth' },
  { name: 'Droplets', label: 'Water / Hygiene' },
  { name: 'Apple', label: 'Nutrition / Apple' },
  { name: 'Flame', label: 'Energy / Streak' },
  { name: 'Brain', label: 'Mindset / Brain' },
  { name: 'Coffee', label: 'Routine / Morning' },
  { name: 'BedDouble', label: 'Sleep / Rest' },
  { name: 'Calendar', label: 'Calendar / Schedule' },
  { name: 'Clock', label: 'Timer / Time' },
  { name: 'Activity', label: 'General / Activity' },
  { name: 'Target', label: 'Goals / Target' },
  { name: 'Smile', label: 'Mood / Smile' },
  { name: 'Music', label: 'Hobbies / Music' },
  { name: 'Briefcase', label: 'Work / Career' },
  { name: 'Home', label: 'House / Family' }
];
