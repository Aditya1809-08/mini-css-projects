import React from 'react';
import { Habit, DailyLog } from '../types';
import { ChevronLeft, ChevronRight, Calendar, Check } from 'lucide-react';

interface HabitTrackerDayCardProps {
  activeDateStr: string; // e.g. "2026-07-01"
  habits: Habit[];
  dailyLogs: DailyLog;
  onToggleHabit: (dateStr: string, habitId: string) => void;
  onChangeDate: (offset: number) => void;
  onSelectToday: () => void;
}

export const HabitTrackerDayCard: React.FC<HabitTrackerDayCardProps> = ({
  activeDateStr,
  habits,
  dailyLogs,
  onToggleHabit,
  onChangeDate,
  onSelectToday,
}) => {
  // Format the active date beautifully: e.g. "October 9, 2022, Thursday"
  const formatDateBeautifully = (dateStr: string) => {
    try {
      const parts = dateStr.split('-');
      if (parts.length === 3) {
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const day = parseInt(parts[2], 10);
        const d = new Date(year, month, day);
        return d.toLocaleDateString('en-US', {
          month: 'long',
          day: 'numeric',
          year: 'numeric',
          weekday: 'long',
        });
      }
    } catch (e) {
      // fallback
    }
    return dateStr;
  };

  const activeLogs = dailyLogs[activeDateStr] || {};

  return (
    <div className="bg-white p-6 sm:p-7 rounded-[32px] border border-[#e6e6db] shadow-xs flex flex-col h-full font-serif">
      {/* Title & Navigation Header */}
      <div className="flex items-center justify-between border-b border-[#e6e6db] pb-4 mb-4">
        <div>
          <h3 className="text-xl font-bold text-[#33332d] tracking-tight">Daily Habit Tracker</h3>
          <p className="text-xs font-semibold text-[#D4A373] mt-1 flex items-center gap-1.5 cursor-pointer hover:underline font-sans italic" onClick={onSelectToday}>
            <Calendar size={12} />
            <span>Go to Today</span>
          </p>
        </div>

        {/* Date shifting buttons */}
        <div className="flex items-center gap-1.5 bg-[#f5f5f0]/80 p-1 rounded-xl border border-[#e6e6db]">
          <button
            onClick={() => onChangeDate(-1)}
            className="p-1.5 hover:bg-white hover:shadow-xs text-[#8a8a70] hover:text-[#33332d] rounded-lg transition cursor-pointer"
            title="Previous Day"
          >
            <ChevronLeft size={16} />
          </button>
          <button
            onClick={() => onChangeDate(1)}
            className="p-1.5 hover:bg-white hover:shadow-xs text-[#8a8a70] hover:text-[#33332d] rounded-lg transition cursor-pointer"
            title="Next Day"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      {/* Beautiful Date display */}
      <div className="text-sm font-semibold text-[#5A5A40] tracking-wide mb-6">
        {formatDateBeautifully(activeDateStr)}
      </div>

      {/* Checklist items */}
      <div className="flex-1 space-y-3.5 font-sans">
        {habits.length === 0 ? (
          <div className="text-center py-12 text-[#8a8a70] text-xs border border-dashed border-[#e6e6db] rounded-2xl bg-[#f5f5f0]/40 italic">
            No habits added. Create habits in the Customizer to start tracking!
          </div>
        ) : (
          habits.map((habit, index) => {
            const isCompleted = !!activeLogs[habit.id];

            return (
              <div
                key={habit.id}
                onClick={() => onToggleHabit(activeDateStr, habit.id)}
                className={`group flex items-center justify-between p-3.5 rounded-2xl border transition duration-200 cursor-pointer ${
                  isCompleted
                    ? 'bg-[#5A5A40]/10 border-[#5A5A40]/30'
                    : 'bg-white border-[#e6e6db] hover:border-[#5A5A40]'
                }`}
              >
                {/* Left side circular checkbox */}
                <div className="flex items-center gap-3">
                  <div
                    className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                      isCompleted
                        ? 'bg-[#5A5A40] border-[#5A5A40] text-white scale-105 shadow-xs'
                        : 'border-[#cbd5c1] group-hover:border-[#5A5A40] bg-white'
                    }`}
                  >
                    {isCompleted && <Check size={11} strokeWidth={3} />}
                  </div>

                  <span
                    className={`text-sm font-bold tracking-tight transition ${
                      isCompleted ? 'text-[#8a8a70] line-through decoration-[#cbd5c1]' : 'text-[#33332d]'
                    }`}
                  >
                    {habit.name}
                  </span>
                </div>

                {/* Right side items: list index number and square check badge */}
                <div className="flex items-center gap-4">
                  <span className="text-xs font-mono font-bold text-[#8a8a70]/70">
                    {index + 1}
                  </span>

                  {/* Right side check status box */}
                  <div
                    className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all ${
                      isCompleted
                        ? 'bg-[#5A5A40]/20 border-[#5A5A40]/40 text-[#5A5A40] scale-102 font-bold'
                        : 'border-[#e6e6db] bg-[#f5f5f0]/40 text-transparent'
                    }`}
                  >
                    <Check size={11} strokeWidth={3.5} />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Completion Metric */}
      {habits.length > 0 && (
        <div className="mt-6 pt-4 border-t border-[#e6e6db]">
          <div className="flex justify-between items-center text-xs text-[#8a8a70] font-semibold font-sans">
            <span>Completed Today</span>
            <span className="text-[#33332d]">
              {Object.values(activeLogs).filter(Boolean).length} / {habits.length}
            </span>
          </div>
          <div className="w-full bg-[#f5f5f0] h-2 rounded-full mt-2 overflow-hidden">
            <div
              className="bg-[#5A5A40] h-full rounded-full transition-all duration-300"
              style={{
                width: `${
                  (Object.values(activeLogs).filter(Boolean).length / habits.length) * 100
                }%`,
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};
