import React from 'react';
import { RoutineItem, Habit } from '../types';
import { Sun, Moon, Plus } from 'lucide-react';

interface RoutineBlockProps {
  routines: RoutineItem[];
  habits: Habit[];
  onAddRoutine: () => void;
}

export const RoutineBlock: React.FC<RoutineBlockProps> = ({ routines, habits, onAddRoutine }) => {
  const morningRoutines = routines.filter((r) => r.period === 'Morning');
  const eveningRoutines = routines.filter((r) => r.period === 'Evening');

  const renderRoutineItem = (item: RoutineItem) => {
    const habit = habits.find((h) => h.id === item.habitId);
    if (!habit) return null;

    return (
      <div key={item.id} className="text-[#33332d] font-bold text-xs py-1.5 flex justify-between items-center border-b border-[#f5f5f0]/80 last:border-b-0">
        <span>{habit.name}</span>
        <span className="text-[#8a8a70] font-bold font-sans">({item.time})</span>
      </div>
    );
  };

  return (
    <div className="font-serif">
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-lg font-bold text-[#33332d]">Routine Block</h3>
        <button
          onClick={onAddRoutine}
          className="text-xs text-[#D4A373] font-bold hover:text-[#5A5A40] flex items-center gap-1 font-sans cursor-pointer"
        >
          <Plus size={12} />
          <span>Edit Routine</span>
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Morning Block */}
        <div className="bg-white p-5 rounded-[24px] border border-[#e6e6db] shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-[#33332d] font-bold text-sm mb-3.5">
              <Sun size={15} className="text-[#D4A373]" />
              <span>Morning</span>
            </div>

            <div className="space-y-1 font-sans">
              {morningRoutines.length === 0 ? (
                <p className="text-[11px] text-[#8a8a70] italic">No morning items</p>
              ) : (
                morningRoutines.map(renderRoutineItem)
              )}
            </div>
          </div>
        </div>

        {/* Evening Block */}
        <div className="bg-white p-5 rounded-[24px] border border-[#e6e6db] shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-1.5 text-[#33332d] font-bold text-sm mb-3.5">
              <Moon size={15} className="text-[#5A5A40]" />
              <span>Evening</span>
            </div>

            <div className="space-y-1 font-sans">
              {eveningRoutines.length === 0 ? (
                <p className="text-[11px] text-[#8a8a70] italic">No evening items</p>
              ) : (
                eveningRoutines.map(renderRoutineItem)
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
