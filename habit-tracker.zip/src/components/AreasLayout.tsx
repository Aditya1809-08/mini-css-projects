import React from 'react';
import { Area, Habit } from '../types';
import { IconRenderer } from './IconRenderer';
import { Settings, Plus } from 'lucide-react';

interface AreasLayoutProps {
  areas: Area[];
  habits: Habit[];
  activeFilterAreaId: string | null;
  onSelectAreaFilter: (areaId: string | null) => void;
  onOpenManageAreas: () => void;
}

export const AreasLayout: React.FC<AreasLayoutProps> = ({
  areas,
  habits,
  activeFilterAreaId,
  onSelectAreaFilter,
  onOpenManageAreas,
}) => {
  // First row vs second row distribution to match the double-row staggered layout in the image
  // Let's divide them beautifully
  const halfLength = Math.ceil(areas.length / 2);
  const row1 = areas.slice(0, halfLength);
  const row2 = areas.slice(halfLength);

  const renderAreaBadge = (area: Area) => {
    const count = habits.filter((h) => h.areaId === area.id).length;
    const isActive = activeFilterAreaId === area.id;

    // We can also swap out background colors dynamically for an earthy theme
    // But maintaining the user's custom area colors is good, we just replace teal focus rings and border colors with Natural Tones
    return (
      <button
        key={area.id}
        onClick={() => onSelectAreaFilter(isActive ? null : area.id)}
        className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-xs font-bold transition-all duration-200 cursor-pointer ${
          isActive
            ? 'ring-2 ring-[#5A5A40] scale-102 border-[#5A5A40]/50 shadow-xs'
            : 'hover:bg-[#f5f5f0]/40 border-[#e6e6db]'
        } ${area.color}`}
      >
        <IconRenderer name={area.icon} size={14} className="shrink-0 text-[#5A5A40]" />
        <span className="truncate">{area.name}</span>
        <span className="opacity-70 font-sans">({count})</span>
      </button>
    );
  };

  return (
    <div className="w-full flex flex-col gap-2 font-sans">
      {/* Row 1 */}
      <div className="flex flex-wrap items-center gap-2">
        {row1.map(renderAreaBadge)}
      </div>

      {/* Row 2 */}
      <div className="flex flex-wrap items-center gap-2">
        {/* "Areas" layout anchor capsule matching the image precisely */}
        <button
          onClick={() => onSelectAreaFilter(null)}
          className={`flex items-center justify-center px-6 py-2.5 rounded-xl border text-xs font-bold transition-all duration-150 cursor-pointer ${
            activeFilterAreaId === null
              ? 'bg-[#5A5A40] border-[#5A5A40] text-white shadow-xs'
              : 'bg-white border-[#e6e6db] text-[#8a8a70] hover:bg-[#f5f5f0]/50 hover:text-[#33332d]'
          }`}
        >
          <span>All Areas</span>
        </button>

        {row2.map(renderAreaBadge)}

        {/* Plus / Config button */}
        <button
          onClick={onOpenManageAreas}
          className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-dashed border-[#e6e6db] text-xs font-bold text-[#8a8a70] hover:text-[#5A5A40] hover:border-[#5A5A40] transition-all bg-white cursor-pointer ml-auto"
        >
          <Plus size={12} />
          <span>Edit Categories</span>
        </button>
      </div>
    </div>
  );
};
