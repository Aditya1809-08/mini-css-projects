import { Area, Habit, RoutineItem, DailyLog } from './types';

export const DEFAULT_AREAS: Area[] = [
  { id: 'area-personal', name: 'Personal', icon: 'User', color: 'bg-indigo-50 text-indigo-600 border-indigo-100' },
  { id: 'area-fitness', name: 'Fitness', icon: 'Dumbbell', color: 'bg-emerald-50 text-emerald-600 border-emerald-100' },
  { id: 'area-learning', name: 'Learning', icon: 'BookOpen', color: 'bg-amber-50 text-amber-600 border-amber-100' },
  { id: 'area-finance', name: 'Finance', icon: 'DollarSign', color: 'bg-sky-50 text-sky-600 border-sky-100' },
  { id: 'area-health', name: 'Health', icon: 'HeartPulse', color: 'bg-rose-50 text-rose-600 border-rose-100' },
  { id: 'area-selfdev', name: 'Self development', icon: 'Sprout', color: 'bg-teal-50 text-teal-600 border-teal-100' },
];

export const DEFAULT_HABITS: Habit[] = [
  {
    id: 'habit-reading',
    name: 'Reading',
    areaId: 'area-learning',
    difficulty: 'Easy',
    time: '30 min',
    icon: 'BookOpen',
  },
  {
    id: 'habit-shower',
    name: 'Cold shower',
    areaId: 'area-fitness',
    difficulty: 'Medium',
    time: '20 min',
    icon: 'Droplets',
  },
  {
    id: 'habit-workout',
    name: 'Workout',
    areaId: 'area-fitness',
    difficulty: 'Hard',
    time: '45 min',
    icon: 'Dumbbell',
  },
  {
    id: 'habit-eating',
    name: 'Healthy eating',
    areaId: 'area-health',
    difficulty: 'Hard',
    time: '20 min',
    icon: 'Apple',
  },
];

export const DEFAULT_ROUTINE: RoutineItem[] = [
  {
    id: 'routine-1',
    habitId: 'habit-workout',
    time: '45 min',
    period: 'Morning',
  },
  {
    id: 'routine-2',
    habitId: 'habit-shower',
    time: '5 min',
    period: 'Morning',
  },
  {
    id: 'routine-3',
    habitId: 'habit-reading',
    time: '30 min',
    period: 'Evening',
  },
];

export const DEFAULT_LOGS: DailyLog = {
  // Pre-check a couple of items for today or yesterday to make it look realistic
};
