/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { UserProfile, Area, Habit, RoutineItem, DailyLog } from './types';
import { DEFAULT_AREAS, DEFAULT_HABITS, DEFAULT_ROUTINE, DEFAULT_LOGS } from './defaultData';
import { LoginPage } from './components/LoginPage';
import { AreasLayout } from './components/AreasLayout';
import { HabitCard } from './components/HabitCard';
import { RoutineBlock } from './components/RoutineBlock';
import { HabitTrackerDayCard } from './components/HabitTrackerDayCard';
import { EditModal } from './components/EditModal';
import { LogOut, Plus, Sparkles, Trophy, Info, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  // Authentication State
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    const cached = localStorage.getItem('habit_tracker_user');
    return cached ? JSON.parse(cached) : null;
  });

  // Core Data States
  const [areas, setAreas] = useState<Area[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [routines, setRoutines] = useState<RoutineItem[]>([]);
  const [dailyLogs, setDailyLogs] = useState<DailyLog>({});

  // Active UI States
  const [activeDateStr, setActiveDateStr] = useState<string>(() => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  });
  
  const [activeFilterAreaId, setActiveFilterAreaId] = useState<string | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [modalInitialTab, setModalInitialTab] = useState<'habits' | 'areas' | 'routines'>('habits');
  const [showExploreAlert, setShowExploreAlert] = useState(false);

  // Load and Bind Scoped Data on User Log In
  useEffect(() => {
    if (!userProfile) return;

    // Scoped storage key
    const userStorageKey = `habit_tracker_data_${userProfile.email}`;
    const cachedData = localStorage.getItem(userStorageKey);

    if (cachedData) {
      try {
        const parsed = JSON.parse(cachedData);
        setAreas(parsed.areas || DEFAULT_AREAS);
        setHabits(parsed.habits || DEFAULT_HABITS);
        setRoutines(parsed.routines || DEFAULT_ROUTINE);
        setDailyLogs(parsed.dailyLogs || DEFAULT_LOGS);
      } catch (e) {
        console.error('Error parsing stored user data', e);
        loadDefaults();
      }
    } else {
      loadDefaults();
    }
  }, [userProfile]);

  const loadDefaults = () => {
    setAreas(DEFAULT_AREAS);
    setHabits(DEFAULT_HABITS);
    setRoutines(DEFAULT_ROUTINE);
    setDailyLogs(DEFAULT_LOGS);
    saveToStorage(DEFAULT_AREAS, DEFAULT_HABITS, DEFAULT_ROUTINE, DEFAULT_LOGS);
  };

  // Persist State Updates Helper
  const saveToStorage = (
    updatedAreas: Area[],
    updatedHabits: Habit[],
    updatedRoutines: RoutineItem[],
    updatedLogs: DailyLog
  ) => {
    if (!userProfile) return;
    const userStorageKey = `habit_tracker_data_${userProfile.email}`;
    const payload = {
      areas: updatedAreas,
      habits: updatedHabits,
      routines: updatedRoutines,
      dailyLogs: updatedLogs,
    };
    localStorage.setItem(userStorageKey, JSON.stringify(payload));
  };

  // State update handlers which also push to scoped LocalStorage
  const handleSaveAreas = (updatedAreas: Area[]) => {
    setAreas(updatedAreas);
    saveToStorage(updatedAreas, habits, routines, dailyLogs);
  };

  const handleSaveHabits = (updatedHabits: Habit[]) => {
    setHabits(updatedHabits);
    saveToStorage(areas, updatedHabits, routines, dailyLogs);
  };

  const handleSaveRoutines = (updatedRoutines: RoutineItem[]) => {
    setRoutines(updatedRoutines);
    saveToStorage(areas, habits, updatedRoutines, dailyLogs);
  };

  const handleToggleHabit = (dateStr: string, habitId: string) => {
    const updatedLogs = { ...dailyLogs };
    if (!updatedLogs[dateStr]) {
      updatedLogs[dateStr] = {};
    }
    updatedLogs[dateStr][habitId] = !updatedLogs[dateStr][habitId];
    setDailyLogs(updatedLogs);
    saveToStorage(areas, habits, routines, updatedLogs);
  };

  const handleLogin = (profile: UserProfile) => {
    setUserProfile(profile);
    localStorage.setItem('habit_tracker_user', JSON.stringify(profile));
  };

  const handleLogout = () => {
    if (confirm('Are you sure you want to sign out? Your habits are stored locally on this machine.')) {
      setUserProfile(null);
      localStorage.removeItem('habit_tracker_user');
      setAreas([]);
      setHabits([]);
      setRoutines([]);
      setDailyLogs({});
    }
  };

  // Date Navigation Shifter
  const handleShiftDate = (offsetDays: number) => {
    const parts = activeDateStr.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      
      const current = new Date(year, month, day);
      current.setDate(current.getDate() + offsetDays);
      
      const yyyy = current.getFullYear();
      const mm = String(current.getMonth() + 1).padStart(2, '0');
      const dd = String(current.getDate()).padStart(2, '0');
      setActiveDateStr(`${yyyy}-${mm}-${dd}`);
    }
  };

  const handleSetToday = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    setActiveDateStr(`${yyyy}-${mm}-${dd}`);
  };

  const triggerOpenModal = (tab: 'habits' | 'areas' | 'routines') => {
    setModalInitialTab(tab);
    setIsEditModalOpen(true);
  };

  // Filter habits list according to active filter
  const filteredHabits = activeFilterAreaId
    ? habits.filter((h) => h.areaId === activeFilterAreaId)
    : habits;

  // Render Login page if not authenticated
  if (!userProfile) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Calculate dynamic stats
  const totalHabitCount = habits.length;
  const completedTodayCount = dailyLogs[activeDateStr]
    ? Object.values(dailyLogs[activeDateStr]).filter(Boolean).length
    : 0;

  return (
    <div className="min-h-screen bg-[#f5f5f0] text-[#33332d] pb-16 relative">
      
      {/* Top Floating App Bar */}
      <div className="bg-white/90 backdrop-blur-md border-b border-[#e6e6db] sticky top-0 z-40 px-4 md:px-8 py-3.5 shadow-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[#5A5A40] text-white flex items-center justify-center font-bold text-sm font-serif">
              H
            </div>
            <span className="font-bold text-[#33332d] text-sm tracking-tight hidden sm:inline font-serif">Habit Tracker Studio</span>
          </div>

          <div className="flex items-center gap-3">
            {/* User Profile Badge */}
            <div className="flex items-center gap-2.5 bg-white border border-[#e6e6db] py-1.5 pl-2 pr-3.5 rounded-full font-sans">
              {userProfile.avatarUrl ? (
                <img
                  src={userProfile.avatarUrl}
                  alt={userProfile.name}
                  referrerPolicy="no-referrer"
                  className="w-7 h-7 rounded-full bg-[#f5f5f0] border border-[#e6e6db]"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-[#5A5A40]/10 text-[#5A5A40] flex items-center justify-center font-bold text-xs">
                  {userProfile.name[0]}
                </div>
              )}
              <div className="text-left hidden md:block">
                <p className="text-xs font-bold text-[#33332d] leading-none">{userProfile.name}</p>
                <p className="text-[9px] text-[#8a8a70] mt-0.5 max-w-[120px] truncate">{userProfile.email}</p>
              </div>
            </div>

            {/* Logout Trigger */}
            <button
              onClick={handleLogout}
              className="p-2 hover:bg-rose-50 text-[#8a8a70] hover:text-rose-600 rounded-full transition cursor-pointer"
              title="Sign out of Habit Tracker"
            >
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 md:px-8 pt-8">
        
        {/* Title */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-[#4a4a35] font-serif">
            Habit tracker
          </h1>
          <p className="text-[#8a8a70] text-sm mt-2 font-medium font-sans italic">
            Customize habits, establish routines, and track daily goals.
          </p>
        </div>

        {/* Outer Desktop Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* ==================== LEFT COLUMN (7 Span) ==================== */}
          <div className="lg:col-span-7 space-y-8">
            
            {/* Areas Categories Badge Grid */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-[#8a8a70] uppercase tracking-widest pl-1 font-sans">Areas of focus</h3>
              <AreasLayout
                areas={areas}
                habits={habits}
                activeFilterAreaId={activeFilterAreaId}
                onSelectAreaFilter={setActiveFilterAreaId}
                onOpenManageAreas={() => triggerOpenModal('areas')}
              />
            </div>

            {/* Habits Cards Column */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold text-[#33332d] font-serif">Habits</h3>
                  {activeFilterAreaId && (
                    <span className="text-xs bg-[#5A5A40]/10 text-[#5A5A40] border border-[#5A5A40]/20 px-2.5 py-0.5 rounded-full font-bold font-sans">
                      Filtered
                    </span>
                  )}
                </div>
                <button
                  onClick={() => triggerOpenModal('habits')}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-[#e6e6db] text-[#33332d] rounded-xl text-xs font-bold hover:bg-[#f5f5f0]/40 hover:border-[#5A5A40] transition shadow-xs cursor-pointer font-sans"
                >
                  <Plus size={12} />
                  <span>Configure Habits</span>
                </button>
              </div>

              {filteredHabits.length === 0 ? (
                <div className="bg-white py-12 px-6 rounded-[24px] border border-dashed border-[#e6e6db] text-center text-[#8a8a70] font-sans">
                  <p className="text-sm font-semibold">No habits found in this view.</p>
                  <button
                    onClick={() => triggerOpenModal('habits')}
                    className="mt-3 px-4 py-2 bg-[#D4A373] text-white rounded-full text-xs font-bold hover:bg-[#c69363] transition shadow-xs cursor-pointer"
                  >
                    Create Your First Habit
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {filteredHabits.map((habit) => (
                    <HabitCard
                      key={habit.id}
                      habit={habit}
                      area={areas.find((a) => a.id === habit.areaId)}
                      onEdit={() => triggerOpenModal('habits')}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Routine Block Grid (Morning & Evening) */}
            <RoutineBlock
              routines={routines}
              habits={habits}
              onAddRoutine={() => triggerOpenModal('routines')}
            />

          </div>

          {/* ==================== RIGHT COLUMN (5 Span) ==================== */}
          <div className="lg:col-span-5">
            <HabitTrackerDayCard
              activeDateStr={activeDateStr}
              habits={habits}
              dailyLogs={dailyLogs}
              onToggleHabit={handleToggleHabit}
              onChangeDate={handleShiftDate}
              onSelectToday={handleSetToday}
            />
          </div>

        </div>

        {/* Bottom Consistency & Inspiration Branding Footer Section */}
        <div className="mt-16 text-center space-y-6">
          <p className="text-[#33332d] font-bold text-lg tracking-tight px-4 max-w-lg mx-auto font-serif italic">
            "Consistency is key to building lasting habits."
          </p>

          <div className="text-xs text-[#8a8a70] font-medium font-sans">
            Created by <span className="text-[#5A5A40] font-bold">{userProfile.name}</span>. More templates | Contact
          </div>

          <div className="flex justify-center font-sans">
            <button
              onClick={() => setShowExploreAlert(true)}
              className="px-6 py-3 border border-[#5A5A40] rounded-full text-xs font-bold text-[#5A5A40] bg-white hover:bg-[#5A5A40] hover:text-white transition duration-200 tracking-wide shadow-xs cursor-pointer"
            >
              Explore this habit tracker template!
            </button>
          </div>
        </div>

      </main>

      {/* Editor customizer modal */}
      <EditModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        areas={areas}
        habits={habits}
        routines={routines}
        onSaveAreas={handleSaveAreas}
        onSaveHabits={handleSaveHabits}
        onSaveRoutines={handleSaveRoutines}
        initialTab={modalInitialTab}
      />

      {/* Explore template dialog alert */}
      <AnimatePresence>
        {showExploreAlert && (
          <div className="fixed inset-0 bg-[#33332d]/40 backdrop-blur-xs z-50 flex items-center justify-center p-4 font-serif">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white max-w-md w-full p-6 rounded-[32px] border border-[#e6e6db] shadow-xl relative"
            >
              <h4 className="text-lg font-bold text-[#33332d] flex items-center gap-2 mb-2">
                <Trophy className="text-[#D4A373] animate-bounce" size={20} />
                <span>Habit Tracker Active!</span>
              </h4>
              <p className="text-xs text-[#8a8a70] leading-relaxed font-sans">
                You are currently exploring a high-fidelity habit tracking platform. You can:
              </p>
              <ul className="text-xs text-[#33332d] space-y-2 mt-3 list-disc pl-4 font-bold font-sans">
                <li>Check off daily habits using the left and right indicators.</li>
                <li>Flick back and forth between past or future dates with calendar arrows.</li>
                <li>Add, modify, delete or recolor any of the Area Categories.</li>
                <li>Create and configure custom habits with timing intervals.</li>
                <li>Log in with multiple Gmail usernames to check independent memory scopes!</li>
              </ul>
              <button
                onClick={() => setShowExploreAlert(false)}
                className="mt-6 w-full py-2.5 bg-[#D4A373] hover:bg-[#c69363] text-white rounded-full text-xs font-bold transition shadow-xs cursor-pointer font-sans"
              >
                Let's Build Habits!
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
