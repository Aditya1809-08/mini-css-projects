export type Difficulty = 'Easy' | 'Medium' | 'Hard';

export interface UserProfile {
  email: string;
  name: string;
  avatarUrl?: string;
}

export interface Area {
  id: string;
  name: string;
  icon: string; // Lucide icon name
  color: string; // Tailwind color class or hex
}

export interface Habit {
  id: string;
  name: string;
  areaId: string; // Linked to Area
  difficulty: Difficulty;
  time: string; // e.g., "30 min"
  icon: string; // Lucide icon name
}

export interface RoutineItem {
  id: string;
  habitId: string; // Linked to Habit
  customName?: string; // Optional custom display name
  time: string; // e.g., "45 min"
  period: 'Morning' | 'Evening';
}

export interface DailyLog {
  // Mapping of date string (e.g., "2026-07-01") to habit IDs completion states
  [dateStr: string]: {
    [habitId: string]: boolean;
  };
}
